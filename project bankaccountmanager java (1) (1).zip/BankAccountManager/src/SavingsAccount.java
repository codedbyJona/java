public class SavingsAccount extends BankAccount {
    private static final double INTEREST_RATE = 0.01;

    public SavingsAccount() {
        super();
    }

    @Override
    public void deposit(double amount) {
        super.deposit(amount * (1 + INTEREST_RATE));
    }
}
