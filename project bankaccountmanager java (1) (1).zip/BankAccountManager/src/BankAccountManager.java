import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BankAccountManager {
    private BankAccount basicAccount;
    private BankAccount savingsAccount;
    private JFrame frame;
    private JTextField basicAccountField;
    private JTextField savingsAccountField;

    public void createAndShowGUI() {
        frame = new JFrame("Bank Account Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        JPanel accountPanel = new JPanel();
        accountPanel.setLayout(new GridLayout(4, 2));

        JLabel basicAccountLabel = new JLabel("Basic Account:");
        basicAccountField = new JTextField();
        basicAccountField.setEditable(false);

        JLabel savingsAccountLabel = new JLabel("Savings Account:");
        savingsAccountField = new JTextField();
        savingsAccountField.setEditable(false);

        accountPanel.add(basicAccountLabel);
        accountPanel.add(basicAccountField);
        accountPanel.add(savingsAccountLabel);
        accountPanel.add(savingsAccountField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 4));

        JButton depositButton = new JButton("Deposit");
        JButton withdrawButton = new JButton("Withdraw");
        JButton balanceButton = new JButton("Balance");
        JButton transferButton = new JButton("Transfer");

        depositButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String input = JOptionPane.showInputDialog("Enter amount to deposit:");
                if (input != null) {
                    double amount = Double.parseDouble(input);
                    basicAccount.deposit(amount);
                    savingsAccount.deposit(amount);
                    updateFields();
                }
            }
        });

        withdrawButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String input = JOptionPane.showInputDialog("Enter amount to withdraw:");
                if (input != null) {
                    double amount = Double.parseDouble(input);
                    basicAccount.withdraw(amount);
                    savingsAccount.withdraw(amount);
                    updateFields();
                }
            }
        });

        balanceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateFields();
            }
        });

        transferButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String input = JOptionPane.showInputDialog("Enter amount to transfer from basic to savings:");
                if (input != null) {
                    double amount = Double.parseDouble(input);
                    basicAccount.transferTo(savingsAccount, amount);
                    updateFields();
                }
            }
        });

        buttonPanel.add(depositButton);
        buttonPanel.add(withdrawButton);
        buttonPanel.add(balanceButton);
        buttonPanel.add(transferButton);

        mainPanel.add(accountPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        frame.getContentPane().add(mainPanel);
        frame.setVisible(true);

        basicAccount = new BasicAccount();
        savingsAccount = new SavingsAccount();
        updateFields();
    }

    private void updateFields() {
        basicAccountField.setText(String.valueOf(basicAccount.getBalance()));
        savingsAccountField.setText(String.valueOf(savingsAccount.getBalance()));
    }
}